package com.teg.tryout.pages;

import com.teg.tryout.utils.ElementFinder;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Map;

public class PremierTicketekPage {

    private WebDriver driver;
    private ElementFinder finder;

    public PremierTicketekPage(WebDriver driver) {
        this.driver = driver;
        this.finder = new ElementFinder(driver);
    }

    private static final String URL = "https://premier.ticketek.com.au";

    /**
     * Open the Ticketek event page and wait until the menu button is present.
     */
    public void open() {
        driver.get(URL);
		
            System.out.println("Page1");
try {
    Thread.sleep(20000); // 20 seconds
} catch (InterruptedException e) {
    e.printStackTrace();
}
            System.out.println("Page2");
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//a[@title='Show menu options']")
            ));
            System.out.println("Page opened successfully, menu button present.");
        } catch (TimeoutException e) {
            System.out.println("Warning: menu button not visible after 5s — JS may still be loading.");
        }
    }

    public WebElement findElementByText(String text) {

        List<String> xpaths = List.of(
                "//a[@title='" + text + "']",
                "//a[text()='" + text + "']",
                "//button[text()='" + text + "']",
                "//span[text()='" + text + "']",
				"//input[@id=//label[normalize-space()='" + text + "']/@for]",
				"//input[@type='submit' and @value='" + text + "']"
        );

        boolean foundElement = false;
        long endTime = System.currentTimeMillis() + 5000; // total 5s wait

        for (String xpath : xpaths) {
            while (System.currentTimeMillis() < endTime) {
                try {
                    List<WebElement> candidates = driver.findElements(By.xpath(xpath));
                    if (candidates.isEmpty()) {
                        System.out.println("No candidates found for XPATH: " + xpath);
                        break;
                    }

                    for (WebElement el : candidates) {
                        if (el.isDisplayed() && el.isEnabled()) {
                            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);
                            Thread.sleep(100); // allow JS animations
                            // el.click();
                            // System.out.println("Clicked element '" + text + "' using XPATH: " + xpath);
                            foundElement = true;
							return el;
                            // return;
                        } else {
                            System.out.println("Candidate found but not clickable (displayed="
                                    + el.isDisplayed() + ", enabled=" + el.isEnabled() + "): " + xpath);
                        }
                    }

                    break; // done with this xpath, move to next if nothing clicked

                } catch (StaleElementReferenceException | InterruptedException e) {
                    System.out.println("Stale element for XPATH: " + xpath + " — retrying...");
                }
            }
        }

        if (!foundElement) {
            throw new RuntimeException("Could not find clickable element for text: " + text);
        }
		return null;
    }

    public void clickElementByText(String text) {
        WebElement foundElement = findElementByText(text);
		foundElement.click();
    }

    public void updateTextElement(String text, String newText) {

        WebElement foundElement = findElementByText(text);
		if (foundElement == null)
			            throw new RuntimeException("Could not find clickable element for text: " + text);
		
		foundElement.click();
		foundElement.sendKeys(newText);
    }
}
